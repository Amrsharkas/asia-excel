<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOneOnOneTables extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::create('one_courses', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('section_id')->nullable();
            $table->string('title')->nullable();
            $table->string('section_image')->nullable();
            $table->string('course_image')->nullable();
            $table->text('description_overall')->nullable();
            $table->text('description_section')->nullable();
            $table->text('description_course')->nullable();
            $table->integer('max_frequency')->nullable();
            $table->float('session_duration')->nullable();
            $table->float('max_start_date')->nullable();
            $table->boolean('has_vc')->nullable(); //virtual classroom
            $table->string('arabic_proficiency')->nullable();
            $table->timestamps();
        });
        Schema::create('one_sessions_pricing', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('course_id')->nullable();
            $table->integer('count')->nullable(); // count of sessions
            $table->boolean('premium_teacger')->nullable();
            $table->boolean('premium_time')->nullable();
            $table->decimal('price')->nullable();
            $table->timestamps();
        });
        Schema::create('one_levels', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('course_id')->nullable(); //one_courses.id
            $table->string('title')->nullable();
            //paths
            $table->string('hw')->nullable();
            $table->string('material')->nullable();
            $table->timestamps();
        });
        Schema::create('one_schedules', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('course_id')->nullable(); //one_courses.id
            $table->integer('student_id')->nullable();
            $table->integer('teacher_id')->nullable();
            $table->string('vc_link')->nullable();
            $table->integer('frequency')->nullable();
            $table->integer('sessions_count')->nullable();
            $table->integer('shift_id')->nullable();
            $table->date('start_date');
            // approved : false meaning this is just an enrollment request and not yet a real schedule
            $table->boolean('approved')->nullable();
            // this structure for days from and to may change .. 
            $table->time('saturday_from')->nullable();
            $table->time('saturday_to')->nullable();
            $table->time('sunday_from')->nullable();
            $table->time('sunday_to')->nullable();
            $table->time('monday_from')->nullable();
            $table->time('monday_to')->nullable();
            $table->time('tuesday_from')->nullable();
            $table->time('tuesday_to')->nullable();
            $table->time('wednesday_from')->nullable();
            $table->time('wednesday_to')->nullable();
            $table->time('thursday_from')->nullable();
            $table->time('thursday_to')->nullable();
            $table->time('friday_from')->nullable();
            $table->time('friday_to')->nullable();
            //from and to
            $table->timestamps();
        });
        // after one_schedule is approved a $one_schedule.sessions_count entries are added to this table
        // the date, from, to for each sessions are calculated from the one_shcedule and other fields are 
        // filled after the session ends
        Schema::create('one_sessions', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('course_id')->nullable(); //one_courses.id
            $table->integer('schedule_id')->nullable(); //one_schedules.id
            $table->time('from')->nullable();
            $table->time('to')->nullable();
            $table->date('date')->nullable();
            //simple text
            $table->string('hw')->nullable();
            $table->strimg('material')->nullable();
            $table->string('attached_hw')->nullable(); //path
            // 0 : on time , -1  absent ,positive number : count of late minutes
            $table->integer('teacher_late_minutes')->nullable();
            // 0 : on time , -1  absent ,positive number : count of late minutes
            $table->integer('student_late_minutes')->nullable();
            // 1 : student absend, 2 teacher absend,3 emergency leave, 4 connection problem
            $table->integer('cancel_status')->nullable();
            $table->integer('level_id')->nullable(); //one_levels.id OR we can store the only the name of the level
            $table->float('grade')->nullable(); // ?
            $table->time('actual_from')->nullable();
            $table->time('actual_to')->nullable();
            $table->string('lesson_name')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();
        });
        //when teacher is marked that he can teach some one on one course, it's saved here 
        Schema::create('one_teachers',function (Blueprint $table){
            $table->integer('course_id'); //one_courses.id
            $table->integer('teacher_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::drop('one_courses');
        Schema::drop('one_sessions_pricing');
        Schema::drop('one_levels');
        Schema::drop('one_data');
        Schema::drop('one_schedules');
        Schema::drop('one_sessions');
    }

}
